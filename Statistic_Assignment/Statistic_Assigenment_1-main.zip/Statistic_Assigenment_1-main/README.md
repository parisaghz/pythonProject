# Statistic_Assigenment_1
member-python-code
